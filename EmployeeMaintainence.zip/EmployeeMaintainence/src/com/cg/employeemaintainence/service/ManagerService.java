package com.cg.employeemaintainence.service;

import java.util.List;

import com.cg.employeemaintainence.dto.Employee;
import com.cg.employeemaintainence.dto.Leave;

public interface ManagerService {
	public Employee searchEmployeeById(int empId);
	public List<Employee> searchEmployeeByName(String fName);
	public Employee displayOwnDetails();
	public List<Employee> displaySubEmployees(int managerId);
	public boolean accept(int leaveId);
	public boolean reject(int leaveId,String reason);
	public List<Leave> showLeavesApplied(int managerId);
}
