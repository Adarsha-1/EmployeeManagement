package com.cg.employeemaintainence.service;

import java.util.List;

import com.cg.employeemaintainence.dao.ManagerDAO;
import com.cg.employeemaintainence.dao.ManagerDAOImpl;
import com.cg.employeemaintainence.dto.Employee;
import com.cg.employeemaintainence.dto.Leave;


public class ManagerServiceImpl implements ManagerService{
	
	ManagerDAO managerDto=new ManagerDAOImpl();

	@Override
	public boolean accept(int leaveId) {
		// TODO Auto-generated method stub
		return managerDto.accept(leaveId);
	}

	@Override
	public boolean reject(int leaveId,String reason) {
		// TODO Auto-generated method stub
		return managerDto.reject(leaveId,reason);
	}

	@Override
	public List<Leave> showLeavesApplied(int managerId) {
		// TODO Auto-generated method stub
		return managerDto.showLeavesApplied(managerId);
	}

	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return managerDto.searchEmployeeById(empId);
	}

	@Override
	public List<Employee> searchEmployeeByName(String fName) {
		// TODO Auto-generated method stub
		return managerDto.searchEmployeeByName(fName);
	}

	@Override
	public Employee displayOwnDetails() {
		// TODO Auto-generated method stub
		return managerDto.displayOwnDetials();
	}

	@Override
	public List<Employee> displaySubEmployees(int managerId) {
		// TODO Auto-generated method stub
		return managerDto.displaySubEmployees(managerId);
	}

}
