package com.cg.employeemaintainence.service;

import com.cg.employeemaintainence.dao.LoginDAO;
import com.cg.employeemaintainence.dao.LoginDAOImpl;

public class LoginServiceImpl implements LoginService{

	private LoginDAO loginDao=new LoginDAOImpl();
	@Override
	public boolean validate(String userName, String password, String userRole) {
		// TODO Auto-generated method stub
		return loginDao.validate(userName, password, userRole);
	}

}
