package com.cg.employeemaintainence.service;

public interface LoginService {
	public boolean validate(String userName,String password,String userRole);
}
