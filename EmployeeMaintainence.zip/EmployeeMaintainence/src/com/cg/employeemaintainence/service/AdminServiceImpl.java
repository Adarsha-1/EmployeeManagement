package com.cg.employeemaintainence.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.employeemaintainence.dao.AdminDAO;
import com.cg.employeemaintainence.dao.AdminDAOImpl;
import com.cg.employeemaintainence.dto.Employee;


public class AdminServiceImpl implements AdminService{

	AdminDAO adminDao=new AdminDAOImpl();
	@Override
	public boolean addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return adminDao.addEmployee(emp);
	}

	@Override
	public boolean deleteEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return adminDao.deleteEmployeeById(empId);
	}

	@Override
	public Employee modifyEmployeeById(int empId,String empName,float salary,int departmentId, LocalDate dateOfBirth,
			Integer contactNumber) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeById(empId,empName,salary,departmentId, dateOfBirth,
				contactNumber);
	}

	@Override
	public List<Employee> displayEmployees() {
		// TODO Auto-generated method stub
		return adminDao.displayEmployees();
	}

	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return adminDao.searchEmployeeById(empId);
	}

	@Override
	public List<Employee> searchEmployessByName(String name) {
		// TODO Auto-generated method stub
		return adminDao.searchEmployessByName(name);
	}

}
