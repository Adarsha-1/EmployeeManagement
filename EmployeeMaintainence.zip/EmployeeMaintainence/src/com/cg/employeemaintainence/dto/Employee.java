package com.cg.employeemaintainence.dto;

import java.time.LocalDate;

public class Employee extends User {
	private int managerId;
	private int noOfLeaves;
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(String userName, float salary, int departmentId, LocalDate dateOfBirth,
			Integer contactNumber, int managerId,int noOfLeaves) {
		super(userName, salary, departmentId, dateOfBirth, contactNumber);
		this.managerId=managerId;
		this.noOfLeaves=noOfLeaves;
		// TODO Auto-generated constructor stub
	}

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public int getNoOfLeaves() {
		return noOfLeaves;
	}

	public void setNoOfLeaves(int noOfLeaves) {
		this.noOfLeaves = noOfLeaves;
	}

	@Override
	public String toString() {
		return super.toString()+"Employee [managerId=" + managerId + ", noOfLeaves=" + noOfLeaves + "]";
	}
	
	

}
