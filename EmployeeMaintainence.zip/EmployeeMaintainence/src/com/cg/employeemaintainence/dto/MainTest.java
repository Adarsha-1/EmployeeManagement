package com.cg.employeemaintainence.dto;

import java.util.List;

import com.cg.employeemaintainence.entity.EmployeeStaticDB;

import java.time.LocalDate;


public class MainTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp=new Employee();
		emp.setUserName("Adarsha Reddy");
		emp.setDepartmentId(1);
		emp.setContactNumber(7894651);
		emp.setDateOfBirth(LocalDate.now());
		emp.setNoOfLeaves(12);
		emp.setManagerId(2);
		emp.setSalary(18000);
		System.out.println(emp);
		EmployeeStaticDB db=new EmployeeStaticDB();
		List<Employee> emp1=db.getEmpList();
		for(Employee e:emp1)
		{
			System.out.println(e);
		}
	}

}
