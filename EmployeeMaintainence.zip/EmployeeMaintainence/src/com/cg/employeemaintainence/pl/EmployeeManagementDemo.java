package com.cg.employeemaintainence.pl;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.cg.employeemaintainence.dao.LoginDAO;
import com.cg.employeemaintainence.dao.LoginDAOImpl;
import com.cg.employeemaintainence.dto.Employee;
import com.cg.employeemaintainence.dto.Leave;
import com.cg.employeemaintainence.service.AdminService;
import com.cg.employeemaintainence.service.AdminServiceImpl;
import com.cg.employeemaintainence.service.EmpService;
import com.cg.employeemaintainence.service.EmpServiceImpl;
import com.cg.employeemaintainence.service.ManagerService;
import com.cg.employeemaintainence.service.ManagerServiceImpl;

public class EmployeeManagementDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Login types:\nAdmin \n Employee\n Manager");
		String loginChoice;
		LoginDAO loginDao=new LoginDAOImpl();
		Scanner scanner=new Scanner(System.in);
		loginChoice=scanner.next();
		String userName;
		String password;
		boolean valid;
		System.out.println("Enter your User Name:");
		userName=scanner.next();
		System.out.println("Enter your password");
		password=scanner.next();
		int choice=0;
		valid=loginDao.validate(userName, password,loginChoice);
		if(valid && loginChoice.equals("admin"))
		{
			do
			{
			System.out.println("Admin:\n1.Add Employee\n2.Delete Employee\n3.Modify employee By Id\n4.Search employee by Id\n5.Search employee by name\n6.display all the employees");
			choice=scanner.nextInt();
			AdminService adminService=new AdminServiceImpl();
			switch(choice)
			{
				case 1:
					Employee emp;
					System.out.println("Enter Employee Name:");
					String empName=scanner.next();
					System.out.println("Enter Employee Salary");
					float empSalary=scanner.nextFloat();
					System.out.println("Enter Employee Department");
					int empDeptId=scanner.nextInt();
					System.out.println("Enter employee date of birth in the format yyyy mm dd");
					int year=scanner.nextInt();
					int month=scanner.nextInt();
					int dayOfMonth=scanner.nextInt();
					LocalDate empDOB=LocalDate.of(year, month, dayOfMonth);
					System.out.println("Enter Employee Contact Number");
					Integer empContactNumber=scanner.nextInt();
					System.out.println("Enter Employee Manager Id");
					int empManagerId=scanner.nextInt();
					emp=new Employee(empName,empSalary,empDeptId,empDOB,empContactNumber,empManagerId,12);
					boolean status=adminService.addEmployee(emp);
					if(status)
					{
						System.out.println("Employee is added successfully");
					}
					break;
				case 2:
					System.out.println("Enter Employee Id for deletion");
					int empDeleteId=scanner.nextInt();
					boolean deletionStatus=adminService.deleteEmployeeById(empDeleteId);
					if(deletionStatus)
					{
						System.out.println("Employee is deleted Sucessfully");
					}
					break;
				case 3:
					//Im writing code for only name modification as of now
					System.out.println("Enter Employee Id for Modification");
					int empToBeModifiedId=scanner.nextInt();
					System.out.println("Enter new Name if you want to change");
					String empNewName=scanner.next();
					System.out.println("Enter new salary");
					float newSalary=scanner.nextFloat();
					System.out.println("Enter new department Id");
					int newDeptId=scanner.nextInt();
					System.out.println("Enter new Date of birth in the format yyyy mm dd");
					int newDOBYear=scanner.nextInt();
					int newDOBMonth=scanner.nextInt();
					int newDOBDate=scanner.nextInt();
					LocalDate newDOB=LocalDate.of(newDOBYear, newDOBMonth, newDOBDate);
					System.out.println("Enter new Contact Number");
					Integer newContactNo=scanner.nextInt();
					Employee modifiedEmp=adminService.modifyEmployeeById(empToBeModifiedId, empNewName,newSalary,newDeptId,newDOB,newContactNo);
					System.out.println("Modified employee details are: "+modifiedEmp);
					break;
				case 4:
					System.out.println("Enter Employee Id for searching");
					int empIdToBESearched=scanner.nextInt();
					Employee searchEmployee=adminService.searchEmployeeById(empIdToBESearched);
					System.out.println("The employee details are: "+searchEmployee);
					break;
				case 5:
					System.out.println("Enter Employee name for searching");
					String empSearchByName=scanner.next();
					List<Employee> employeeList=adminService.searchEmployessByName(empSearchByName);
					for(Employee resultEmp:employeeList)
					{
						System.out.println(resultEmp);
					}
					break;
				case 6:
					List<Employee> empTotalList=adminService.displayEmployees();
					for(Employee totalEmp:empTotalList)
					{
						System.out.println(totalEmp);
					}
					break;
					default:
						System.out.println("Exit/logout");
			}
			}while(choice!=7);
		}
		else if(valid && loginChoice.equals("employee"))
		{
			do
			{
			System.out.println("Employee\n1.Search EMployee By Id\n2.Search employee By Name\n3.Display their own details\n4.change account password\n5.apply for leave\n6.Edit leave\n7.search any leave\n8.cancel any leave");
			choice=scanner.nextInt();
			EmpService employeeService=new EmpServiceImpl();
			switch(choice)
			{
				case 1:
					System.out.println("Enter employee id to be searched");
					int empSearchId=scanner.nextInt();
					Employee searchedEmp=employeeService.searchEmployeeById(empSearchId);
					System.out.println("The employee details are: "+searchedEmp);
					break;
				case 2:
					System.out.println("Enter Employee name to be searched");
					String empName=scanner.next();
					List<Employee> empTotalList=employeeService.searchEmployeeByName(empName);
					for(Employee result:empTotalList)
					{
						System.out.println(result);
					}
					break;
				case 3:
					Employee empOwnDetails=employeeService.displayEmpDetails();
					System.out.println(empOwnDetails);
					break;
				case 4:
					System.out.println("Enter old password");
					String oldPassword=scanner.next();
					System.out.println("Enter new password");
					String newPassword=scanner.next();
					boolean pwdChangeStatus=employeeService.changeAccountPassword(oldPassword, newPassword);
					if(pwdChangeStatus)
					{
						System.out.println("changed successfully");
					}
					break;
				case 6:
					System.out.println("Enter from date in the format yyyy mm dd");
					int fromYear=scanner.nextInt();
					int fromMonth=scanner.nextInt();
					int fromDate=scanner.nextInt();
					LocalDate fDate=LocalDate.of(fromYear, fromMonth, fromDate);
					System.out.println("Enter to date in format yyyy mm dd");
					int toYear=scanner.nextInt();
					int toMonth=scanner.nextInt();
					int toDate=scanner.nextInt();
					LocalDate tDate=LocalDate.of(toYear, toMonth, toMonth);
					LocalDate today=LocalDate.now();
					int empId=loginDao.getEmpId();
					Leave leave=new Leave(fDate,tDate,today,false,empId,"");
					boolean leaveStatus=employeeService.addLeave(leave);
					if(leaveStatus)
					{
						System.out.println("Sucessfully");
					}
					break;
				case 7:
					System.out.println("Enter leave id to modify leave");
					int leaveId=scanner.nextInt();
					System.out.println("Enter from date in the format yyyy mm dd");
					int fromYear1=scanner.nextInt();
					int fromMonth1=scanner.nextInt();
					int fromDate1=scanner.nextInt();
					LocalDate fDate1=LocalDate.of(fromYear1, fromMonth1, fromDate1);
					System.out.println("Enter to date in format yyyy mm dd");
					int toYear1=scanner.nextInt();
					int toMonth1=scanner.nextInt();
					int toDate1=scanner.nextInt();
					LocalDate tDate1=LocalDate.of(toYear1, toMonth1, toMonth1);
					LocalDate today1=LocalDate.now();
					Leave editedLeave=employeeService.editLeave(leaveId, fDate1, tDate1);
					System.out.println("leave modified to: "+editedLeave);
					break;
				case 8:
					System.out.println("Enter leave id to cancel");
					int leaveIdForCancel=scanner.nextInt();
					boolean leaveCancelStatus=employeeService.cancelLeave(leaveIdForCancel);
					if(leaveCancelStatus)
					{
						System.out.println("Leave is cancelled sucessfully");
					}
					break;
				default:
					System.out.println("Exit/Logout");
			}
			}while(choice!=9);
		}
		else if(valid && loginChoice.equals("manager"))
		{
			do
			{
				System.out.println("Manager\n1.Search By employee Id\n2.Search employee by name\n3.Display own details\n4.Display employees under them\n5.Show leaves applied by employees\n6.Accept leave\n7.Reject leave");
				choice=scanner.nextInt();
				ManagerService managerService=new ManagerServiceImpl();
				switch(choice)
				{
					case 1:
						System.out.println("Enter employee id to be searched");
						int empSearchId=scanner.nextInt();
						Employee searchedEmp=managerService.searchEmployeeById(empSearchId);
						System.out.println("The employee details are: "+searchedEmp);
						break;
					case 2:
						System.out.println("Enter Employee name to be searched");
						String empName=scanner.next();
						List<Employee> empTotalList=managerService.searchEmployeeByName(empName);
						for(Employee result:empTotalList)
						{
							System.out.println(result);
						}
						break;
					case 3:
						Employee empOwnDetails=managerService.displayOwnDetails();
						System.out.println(empOwnDetails);
						break;
					case 4:
						int managerId=loginDao.getEmpId();
						List<Employee> subEmpList=managerService.displaySubEmployees(managerId);
						for(Employee list:subEmpList)
						{
							System.out.println(list);
						}
						break;
					case 5:
						int managerId1=loginDao.getEmpId();
						List<Leave> leaveList=managerService.showLeavesApplied(managerId1);
						for(Leave leave:leaveList)
						{
							System.out.println(leave);
						}
						break;
					case 6:
						System.out.println("Enter leave id to be accepted");
						int leaveId=scanner.nextInt();
						boolean leaveAcceptStatus=managerService.accept(leaveId);
						if(leaveAcceptStatus)
						{
							System.out.println("Leave accepted sucessfully");
						}
						break;
					case 7:
						System.out.println("Enter leave id for rejection");
						int leaveId2=scanner.nextInt();
						System.out.println("Enter reason for rejection");
						String reason=scanner.next();
						boolean rejectStatus=managerService.reject(leaveId2, reason);
						if(rejectStatus)
						{
							System.out.println("Sucessfully rejected");
						}
						break;
					default:
						System.out.println("Exit/Logout");
						
				}
			}while(choice!=7);
		}
		else
		{
			System.out.println("Invalid login credentials");
		}
		
	}

}
