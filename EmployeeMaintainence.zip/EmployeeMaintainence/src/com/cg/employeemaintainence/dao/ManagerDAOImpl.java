package com.cg.employeemaintainence.dao;

import java.util.List;

import com.cg.employeemaintainence.dto.Employee;
import com.cg.employeemaintainence.dto.Leave;


public class ManagerDAOImpl implements ManagerDAO {

	@Override
	public Employee searchEmployeeById(int empId) {
		// the function should return the employee details based on the employee id
		return null;
	}


	@Override
	public boolean accept(int leaveId) {
		// The function should accept the leave based on leaveid and the number of leaves of that particular employee should be decreased.
		return false;
	}

	@Override
	public boolean reject(int leaveId,String reason) {
		//manager can reject a leave by mentioning the reason for it.
		return false;
	}

	@Override
	public List<Leave> showLeavesApplied(int managerId) {
		// it should display all the leaves applied by the employees how have the managerId as manager own id.
		return null;
	}

	@Override
	public List<Employee> searchEmployeeByName(String fName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee displayOwnDetials() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> displaySubEmployees(int managerId) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
