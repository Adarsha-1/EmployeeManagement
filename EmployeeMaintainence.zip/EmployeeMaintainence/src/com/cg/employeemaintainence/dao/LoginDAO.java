package com.cg.employeemaintainence.dao;

public interface LoginDAO {
	public boolean validate(String userName,String pwd,String userRole);
	public int getEmpId();
}
