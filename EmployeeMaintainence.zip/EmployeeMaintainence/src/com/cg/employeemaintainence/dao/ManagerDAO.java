package com.cg.employeemaintainence.dao;

import java.util.List;

import com.cg.employeemaintainence.dto.Employee;
import com.cg.employeemaintainence.dto.Leave;


public interface ManagerDAO {
	public Employee searchEmployeeById(int empId);
	public List<Employee> searchEmployeeByName(String fName);
	public Employee displayOwnDetials();
	public List<Employee> displaySubEmployees(int managerId);
	public boolean accept(int leaveId);
	public boolean reject(int leaveId,String reason);
	public List<Leave> showLeavesApplied(int ManagerId);
}
