package com.cg.employeemaintainence.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.employeemaintainence.dto.Employee;


public class AdminDAOImpl implements AdminDAO{

	@Override
	public boolean addEmployee(Employee emp) {
		// TODO function should add an employee into the table
		return false;
	}

	@Override
	public boolean deleteEmployeeById(int empId) {
		// Function should delete employee based on employee id
		return false;
	}

	@Override
	public Employee modifyEmployeeById(int empId, String empName,float salary,int departmentId, LocalDate dateOfBirth,
			Integer contactNumber) {
		// the function should modify employee details based on employee id
		return null;
	}

	@Override
	public List<Employee> displayEmployees() {
		// the function should return all the employee details present
		return null;
	}

	@Override
	public Employee searchEmployeeById(int empId) {
		// the function should search for an employee based on the employee id.
		return null;
	}

	@Override
	public List<Employee> searchEmployessByName(String name) {
		// the function should search for the employee name present and return all the emp details with matching employee name
		return null;
	}
	
}
