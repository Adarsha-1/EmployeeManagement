package com.cg.employeemaintainence.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.employeemaintainence.dto.Employee;


public interface AdminDAO {
	public boolean addEmployee(Employee emp);
	public boolean deleteEmployeeById(int empId);
	public Employee modifyEmployeeById(int empId,String empName,float salary,int departmentId, LocalDate dateOfBirth,
			Integer contactNumber);
	public Employee searchEmployeeById(int empId);
	public List<Employee> searchEmployessByName(String name);
	public List<Employee> displayEmployees();
}
