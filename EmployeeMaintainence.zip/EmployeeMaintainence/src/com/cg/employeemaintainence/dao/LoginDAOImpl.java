package com.cg.employeemaintainence.dao;

public class LoginDAOImpl implements LoginDAO{

	@Override
	public boolean validate(String userName, String pwd, String userRole) {
		// function should check username and pwd from static loginDB present.
		return false;
	}

	@Override
	public int getEmpId() {
		// Function should return the employee id of the user who have loged in.
		return 0;
	}

}
