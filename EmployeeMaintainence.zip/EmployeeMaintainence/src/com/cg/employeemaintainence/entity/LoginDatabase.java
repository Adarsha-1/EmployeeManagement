package com.cg.employeemaintainence.entity;

import java.util.ArrayList;
import java.util.List;

import com.cg.employeemaintainence.dto.Login;


public class LoginDatabase {
	private static List<Login> loginDB=new ArrayList<Login>();
	static
	{
		loginDB.add(new Login("adarsha","admin","adarsha",1));
	}
	public static List<Login> getLoginDB() {
		return loginDB;
	}
	public static void setLoginDB(List<Login> loginDB) {
		LoginDatabase.loginDB = loginDB;
	}
	
}
