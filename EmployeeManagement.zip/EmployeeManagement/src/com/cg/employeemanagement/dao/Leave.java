package com.cg.employeemanagement.dao;

import java.util.Date;

public class Leave {
	private int leaveId;
	private Date fromDate;
	private Date toDate;
	private Date appliedDate;
	private boolean leaveStatus;
	private int empId;
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public Date getAppliedDate() {
		return appliedDate;
	}
	public void setAppliedDate(Date appliedDate) {
		this.appliedDate = appliedDate;
	}
	public boolean isLeaveStatus() {
		return leaveStatus;
	}
	public void setLeaveStatus(boolean leaveStatus) {
		this.leaveStatus = leaveStatus;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
}
