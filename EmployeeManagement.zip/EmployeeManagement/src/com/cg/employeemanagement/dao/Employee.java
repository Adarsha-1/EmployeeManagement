package com.cg.employeemanagement.dao;

public class Employee extends User {
	private int managerId;
	private int noOfLeaves;
	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public int getNoOfLeaves() {
		return noOfLeaves;
	}

	public void setNoOfLeaves(int noOfLeaves) {
		this.noOfLeaves = noOfLeaves;
	}

	@Override
	public String toString() {
		return super.toString()+"Employee [managerId=" + managerId + ", noOfLeaves=" + noOfLeaves + "]";
	}
	
	

}
