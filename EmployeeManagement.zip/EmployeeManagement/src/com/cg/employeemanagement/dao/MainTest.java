package com.cg.employeemanagement.dao;

import java.util.Date;

public class MainTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp=new Employee();
		emp.setFirstName("adarsha");
		emp.setLastName("reddy");
		emp.setDepartmentId(1);
		emp.setContactNumber(7894651);
		emp.setDateOfBirth(new Date());
		emp.setNoOfLeaves(12);
		emp.setManagerId(2);
		emp.setSalary(18000);
		System.out.println(emp);
	}

}
