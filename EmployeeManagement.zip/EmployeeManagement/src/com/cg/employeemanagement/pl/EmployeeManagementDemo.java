package com.cg.employeemanagement.pl;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.cg.employeemanagement.dao.Employee;
import com.cg.employeemanagement.dao.Leave;
import com.cg.employeemanagement.dto.AdminDTO;
import com.cg.employeemanagement.dto.AdminDTOImpl;
import com.cg.employeemanagement.dto.EmployeeDTO;
import com.cg.employeemanagement.dto.EmployeeDTOImpl;
import com.cg.employeemanagement.dto.LoginDTO;
import com.cg.employeemanagement.dto.LoginDTOImpl;
import com.cg.employeemanagement.dto.ManagerDTO;
import com.cg.employeemanagement.dto.ManagerDTOImpl;

public class EmployeeManagementDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Login types:\nAdmin \n Employee\n Manager");
		String loginChoice;
		LoginDTO loginDto=new LoginDTOImpl();
		Scanner scanner=new Scanner(System.in);
		loginChoice=scanner.next();
		String userName;
		String password;
		boolean valid;
		System.out.println("Enter your User Name:");
		userName=scanner.next();
		System.out.println("Enter your password");
		password=scanner.next();
		valid=loginDto.validate(userName, password,loginChoice);
		if(valid && loginChoice.equals("admin"))
		{
			System.out.println("Admin:\n1.Add Employee\n2.Delete Employee\n3.Modify employee By Id\n4.Search employee by Id\n5.Search employee by name\n6.display all the employees");
			int choice=scanner.nextInt();
			AdminDTO adminDao=new AdminDTOImpl();
			switch(choice)
			{
				case 1:
					Employee emp;
					System.out.println("Enter Employee Name:");
					String empName=scanner.next();
					System.out.println("Enter Employee Salary");
					float empSalary=scanner.nextFloat();
					System.out.println("Enter Employee Department");
					int empDeptId=scanner.nextInt();
					System.out.println("Enter employee date of birth in the format yyyy mm dd");
					int year=scanner.nextInt();
					int month=scanner.nextInt();
					int dayOfMonth=scanner.nextInt();
					LocalDate empDOB=LocalDate.of(year, month, dayOfMonth);
					System.out.println("Enter Employee Contact Number");
					Integer empContactNumber=scanner.nextInt();
					System.out.println("Enter Employee Manager Id");
					int empManagerId=scanner.nextInt();
					emp=new Employee(empName,empSalary,empDeptId,empDOB,empContactNumber,empManagerId,12);
					boolean status=adminDao.addEmployee(emp);
					if(status)
					{
						System.out.println("Employee is added successfully");
					}
					break;
				case 2:
					System.out.println("Enter Employee Id for deletion");
					int empDeleteId=scanner.nextInt();
					boolean deletionStatus=adminDao.deleteEmployeeById(empDeleteId);
					if(deletionStatus)
					{
						System.out.println("Employee is deleted Sucessfully");
					}
					break;
				case 3:
					//Im writing code for only name modification as of now
					System.out.println("Enter Employee Id for Modification");
					int empToBeModifiedId=scanner.nextInt();
					System.out.println("Enter new Name if you want to change");
					String empNewName=scanner.next();
					Employee modifiedEmp=adminDao.modifyEmployeeById(empToBeModifiedId, empNewName);
					System.out.println("Modified employee details are: "+modifiedEmp);
					break;
				case 4:
					System.out.println("Enter Employee Id for searching");
					int empIdToBESearched=scanner.nextInt();
					Employee searchEmployee=adminDao.searchEmployeeById(empIdToBESearched);
					System.out.println("The employee details are: "+searchEmployee);
					break;
				case 5:
					System.out.println("Enter Employee name for searching");
					String empSearchByName=scanner.next();
					List<Employee> employeeList=adminDao.searchEmployessByName(empSearchByName);
					for(Employee resultEmp:employeeList)
					{
						System.out.println(resultEmp);
					}
					break;
				case 6:
					List<Employee> empTotalList=adminDao.displayEmployees();
					for(Employee totalEmp:empTotalList)
					{
						System.out.println(totalEmp);
					}
					break;
					default:
						System.out.println("Exit");
			}
		}
		else if(valid && loginChoice.equals("employee"))
		{
			System.out.println("Employee\n1.Search EMployee By Id\n2.Search employee By Name\n3.Display their own details\n4.change account password\n5.check attendance\n6.apply for leave\n7.Edit leave\n8.search any leave\n9.cancel any leave");
			int employeeChoice=scanner.nextInt();
			EmployeeDTO employeeDto=new EmployeeDTOImpl();
			switch(employeeChoice)
			{
				case 1:
					System.out.println("Enter employee id to be searched");
					int empSearchId=scanner.nextInt();
					Employee searchedEmp=employeeDto.searchEmployeeById(empSearchId);
					System.out.println("The employee details are: "+searchedEmp);
					break;
				case 2:
					System.out.println("Enter Employee name to be searched");
					String empName=scanner.next();
					List<Employee> empTotalList=employeeDto.searchEmployeeByName(empName);
					for(Employee result:empTotalList)
					{
						System.out.println(result);
					}
					break;
				case 3:
					Employee empOwnDetails=employeeDto.displayEmpDetails();
					System.out.println(empOwnDetails);
					break;
				case 4:
					System.out.println("Enter old password");
					String oldPassword=scanner.next();
					System.out.println("Enter new password");
					String newPassword=scanner.next();
					boolean pwdChangeStatus=employeeDto.changeAccountPassword(oldPassword, newPassword);
					if(pwdChangeStatus)
					{
						System.out.println("changed successfully");
					}
					break;
				case 5:
					int attendance=employeeDto.checkAttendance();
					System.out.println("Attendance is: "+attendance);
					break;
				case 6:
					System.out.println("Enter from date in the format yyyy mm dd");
					int fromYear=scanner.nextInt();
					int fromMonth=scanner.nextInt();
					int fromDate=scanner.nextInt();
					LocalDate fDate=LocalDate.of(fromYear, fromMonth, fromDate);
					System.out.println("Enter to date in format yyyy mm dd");
					int toYear=scanner.nextInt();
					int toMonth=scanner.nextInt();
					int toDate=scanner.nextInt();
					LocalDate tDate=LocalDate.of(toYear, toMonth, toMonth);
					LocalDate today=LocalDate.now();
					int empId=0;//write code to get access present employee id;
					Leave leave=new Leave(fDate,tDate,today,false,empId);
					boolean leaveStatus=employeeDto.addLeave(leave);
					if(leaveStatus)
					{
						System.out.println("Sucessfully");
					}
					break;
				case 7:
					System.out.println("Enter leave id to modify leave");
					int leaveId=scanner.nextInt();
					System.out.println("Enter from date in the format yyyy mm dd");
					int fromYear1=scanner.nextInt();
					int fromMonth1=scanner.nextInt();
					int fromDate1=scanner.nextInt();
					LocalDate fDate1=LocalDate.of(fromYear1, fromMonth1, fromDate1);
					System.out.println("Enter to date in format yyyy mm dd");
					int toYear1=scanner.nextInt();
					int toMonth1=scanner.nextInt();
					int toDate1=scanner.nextInt();
					LocalDate tDate1=LocalDate.of(toYear1, toMonth1, toMonth1);
					LocalDate today1=LocalDate.now();
					Leave editedLeave=employeeDto.editLeave(leaveId, fDate1, tDate1);
					System.out.println("leave modified to: "+editedLeave);
					break;
					
					
					
			}
		}
		else
		{
			System.out.println("Invalid login credentials");
		}
		
	}

}
