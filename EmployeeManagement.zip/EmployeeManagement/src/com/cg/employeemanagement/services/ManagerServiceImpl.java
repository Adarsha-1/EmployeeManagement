package com.cg.employeemanagement.services;

import java.util.List;

import com.cg.employeemanagement.dao.Employee;
import com.cg.employeemanagement.dao.Leave;
import com.cg.employeemanagement.dto.ManagerDTO;
import com.cg.employeemanagement.dto.ManagerDTOImpl;

public class ManagerServiceImpl implements ManagerService{
	
	ManagerDTO managerDto=new ManagerDTOImpl();
	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return managerDto.searchEmployeeById(empId);
	}

	@Override
	public Employee display() {
		// TODO Auto-generated method stub
		return managerDto.display();
	}

	@Override
	public boolean accept(int leaveId) {
		// TODO Auto-generated method stub
		return managerDto.accept(leaveId);
	}

	@Override
	public String reject(int leaveId) {
		// TODO Auto-generated method stub
		return managerDto.reject(leaveId);
	}

	@Override
	public List<Leave> showLeavesApplied() {
		// TODO Auto-generated method stub
		return managerDto.showLeavesApplied();
	}

}
