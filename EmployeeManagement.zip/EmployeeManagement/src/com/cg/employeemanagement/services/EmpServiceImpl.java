package com.cg.employeemanagement.services;

import java.time.LocalDate;
import java.util.List;

import com.cg.employeemanagement.dao.Employee;
import com.cg.employeemanagement.dao.Leave;
import com.cg.employeemanagement.dto.EmployeeDTO;
import com.cg.employeemanagement.dto.EmployeeDTOImpl;

public class EmpServiceImpl implements EmpService{

	EmployeeDTO dao=new EmployeeDTOImpl(); 
	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return dao.searchEmployeeById(empId);
	}

	@Override
	public List<Employee> searchEmployeeByName(String fName) {
		// TODO Auto-generated method stub
		return dao.searchEmployeeByName(fName);
	}

	@Override
	public Employee displayEmpDetails() {
		// TODO Auto-generated method stub
		return dao.displayEmpDetails();
	}

	@Override
	public boolean changeAccountPassword(String oldPassword,String newPassword) {
		// TODO Auto-generated method stub
		return dao.changeAccountPassword(oldPassword,newPassword);
	}

	@Override
	public int checkAttendance() {
		// TODO Auto-generated method stub
		return dao.checkAttendance();
	}

	@Override
	public boolean addLeave(Leave leave) {
		// TODO Auto-generated method stub
		return dao.addLeave(leave);
	}

	@Override
	public Leave editLeave(int leaveId,LocalDate fromDate,LocalDate toDate) {
		// TODO Auto-generated method stub
		return dao.editLeave(leaveId,fromDate,toDate);
	}

	@Override
	public Leave SearchLeave(int leaveId) {
		// TODO Auto-generated method stub
		return dao.SearchLeave(leaveId);
	}

	@Override
	public boolean cancelLeave(int leaveId) {
		// TODO Auto-generated method stub
		return dao.cancelLeave(leaveId);
	}

}
