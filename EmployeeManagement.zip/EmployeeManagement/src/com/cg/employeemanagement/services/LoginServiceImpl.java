package com.cg.employeemanagement.services;

import com.cg.employeemanagement.dto.LoginDTO;
import com.cg.employeemanagement.dto.LoginDTOImpl;

public class LoginServiceImpl implements LoginService{

	private LoginDTO loginDto=new LoginDTOImpl();
	@Override
	public boolean validate(String userName, String password, String userRole) {
		// TODO Auto-generated method stub
		return loginDto.validate(userName, password, userRole);
	}

}
