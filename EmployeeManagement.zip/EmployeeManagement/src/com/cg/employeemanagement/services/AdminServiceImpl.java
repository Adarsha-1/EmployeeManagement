package com.cg.employeemanagement.services;

import java.util.List;

import com.cg.employeemanagement.dao.Employee;
import com.cg.employeemanagement.dto.AdminDTO;
import com.cg.employeemanagement.dto.AdminDTOImpl;

public class AdminServiceImpl implements AdminService{

	AdminDTO adminDao=new AdminDTOImpl();
	@Override
	public boolean addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return adminDao.addEmployee(emp);
	}

	@Override
	public boolean deleteEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return adminDao.deleteEmployeeById(empId);
	}

	@Override
	public Employee modifyEmployeeById(int empId,String empName) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeById(empId,empName);
	}

	@Override
	public List<Employee> displayEmployees() {
		// TODO Auto-generated method stub
		return adminDao.displayEmployees();
	}

	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return adminDao.searchEmployeeById(empId);
	}

	@Override
	public List<Employee> searchEmployessByName(String name) {
		// TODO Auto-generated method stub
		return adminDao.searchEmployessByName(name);
	}

}
