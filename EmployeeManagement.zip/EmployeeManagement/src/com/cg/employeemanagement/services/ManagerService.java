package com.cg.employeemanagement.services;

import java.util.List;

import com.cg.employeemanagement.dao.Employee;
import com.cg.employeemanagement.dao.Leave;

public interface ManagerService {
	public Employee searchEmployeeById(int empId);
	public Employee display();
	public boolean accept(int leaveId);
	public String reject(int leaveId);
	public List<Leave> showLeavesApplied();
}
