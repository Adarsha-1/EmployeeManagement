package com.cg.employeemanagement.entity;

import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dao.Department;

public class DepartmentStaticDB {
	private List<Department> departmentList=new ArrayList<Department>();
	public List<Department> getDepartmentDB()
	{
		departmentList.add(new Department(101,"software"));
		departmentList.add(new Department(102,"IT"));
		departmentList.add(new Department(103,"Trainee"));
		departmentList.add(new Department(104,"Hacking"));
		departmentList.add(new Department(105,"programming"));
		return departmentList;
	}
}
