package com.cg.employeemanagement.entity;

import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dao.Login;

public class LoginDatabase {
	private List<Login> loginDB=new ArrayList<Login>();
	public List<Login> getLoginDetails()
	{
		loginDB.add(new Login("adarsha","admin","adarsha"));
		loginDB.add(new Login("chandu","employee","chandu"));
		loginDB.add(new Login("sahail","manager","sahail"));
		return loginDB;
	}
}
