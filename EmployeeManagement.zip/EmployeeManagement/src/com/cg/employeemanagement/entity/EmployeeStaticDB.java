package com.cg.employeemanagement.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dao.Employee;

public class EmployeeStaticDB {
	private List<Employee> empList=new ArrayList<Employee>(); 
	public List<Employee> getEmployeeList()
	{
		
			empList.add(new Employee("Adarsha Reddy",15000,101,LocalDate.of(1998, 12, 28),753992104,2,12));
			empList.add(new Employee("Naresh Babu",18000,102,LocalDate.of(1995, 05, 02),15236984,2,12));
			empList.add(new Employee("suresh",15000,101,LocalDate.of(1989, 01, 26),45698715,3,12));
			empList.add(new Employee("chintu",15000,103,LocalDate.of(1982, 10, 8),23659810,3,12));
			empList.add(new Employee("chandana",15000,104,LocalDate.of(1985, 03, 16),189657483,5,12));
			empList.add(new Employee("priya",15000,105,LocalDate.of(1990, 01, 3),369874561,5,12));
		
		return empList;
	}
	
}
