package com.cg.employeemanagement.dto;

import java.util.List;

import com.cg.employeemanagement.dao.Employee;
import com.cg.employeemanagement.dao.Leave;

public class ManagerDTOImpl implements ManagerDTO {

	@Override
	public Employee searchEmployeeById(int empId) {
		// the function should return the employee details based on the employee id
		return null;
	}

	@Override
	public Employee display() {
		// function should display the employee details of their own.(IF you want you can add parameter to it)
		return null;
	}

	@Override
	public boolean accept(int leaveId) {
		// The function should accept the leave based on leaveid and the number of leaves of that particular employee should be decreased.
		return false;
	}

	@Override
	public String reject(int leaveId) {
		//manager can reject a leave by mentioning the reason for it.
		return null;
	}

	@Override
	public List<Leave> showLeavesApplied() {
		// it should display all the leaves applied by the employees how have the managerId as manager own id.
		return null;
	}
	
}
