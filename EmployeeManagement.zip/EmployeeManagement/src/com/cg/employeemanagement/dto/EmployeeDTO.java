package com.cg.employeemanagement.dto;

import com.cg.employeemanagement.dao.Employee;
import com.cg.employeemanagement.dao.Leave;

public interface EmployeeDTO {
	public Employee searchEmployeeById(int empId);
	public Employee displayEmpDetails();
	public boolean changeAccountPassword();
	public int checkAttendance();
	public boolean addLeave(Leave leave);
	public Leave editLeave(int leaveId);
	public Leave SearchLeave(int leaveId);
	public boolean cancelLeave();
}
