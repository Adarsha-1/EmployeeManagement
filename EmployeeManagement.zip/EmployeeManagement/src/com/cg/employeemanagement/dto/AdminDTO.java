package com.cg.employeemanagement.dto;

import java.util.List;

import com.cg.employeemanagement.dao.Employee;

public interface AdminDTO {
	public boolean addEmployee(Employee emp);
	public boolean deleteEmployeeById(int empId);
	public Employee modifyEmployeeById(int empId,String empName);
	public Employee searchEmployeeById(int empId);
	public List<Employee> searchEmployessByName(String name);
	public List<Employee> displayEmployees();
}
