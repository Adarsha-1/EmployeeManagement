package com.cg.employeemanagement.dto;

public interface LoginDTO {
	public boolean validate(String userName,String pwd,String userRole);
}
