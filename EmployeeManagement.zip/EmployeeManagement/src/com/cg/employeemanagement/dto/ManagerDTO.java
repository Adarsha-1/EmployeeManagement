package com.cg.employeemanagement.dto;

import java.util.List;

import com.cg.employeemanagement.dao.Employee;
import com.cg.employeemanagement.dao.Leave;

public interface ManagerDTO {
	public Employee searchEmployeeById(int empId);
	public Employee display();
	public boolean accept(int leaveId);
	public String reject(int leaveId);
	public List<Leave> showLeavesApplied();
}
